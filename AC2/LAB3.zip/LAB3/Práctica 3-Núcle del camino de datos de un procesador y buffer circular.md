## Práctica 3-Núcle del camino de datos de un procesador y buffer circular



1. Foto

2. El automata principal es el registro 'estadoreg' y los automatas subordinados son 'contador', 'idenL1', 'IdenL2', 'IdenE'.

   La logica de proximo estado depende del registro contador y las entrada Pcero e ini, las puertas lógicas estan situadas arriba a la izquierda en la foto (archivo adjunto capturaEjercicio2.jpg)

3. Tabla

4. Tabla

5. Adjuntamos la imagen en el archivo capturaEjercicio5.png

6. 

